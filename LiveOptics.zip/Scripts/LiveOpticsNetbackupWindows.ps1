﻿<#

.SYNOPSIS
This Powershell script can be run on a server to gather a file collection from a NetBackup instance.
The generated files can be uploaded to LiveOpics through the collector for analysis. 

.DESCRIPTION
This script will run queries against NetBackup and produce .out files for analysis.

.LINK
https://www.liveoptics.com/

#>

#-----------------------------------------------------------------------------
#  Copyright (c) 2017-2018 by Dell Inc. 
# 
#  All rights reserved.  
# 
#-----------------------------------------------------------------------------

param([string]$installationPath)

$scriptVersion="PowerShell.1.0.011";

""
"------------------------------------------------------";
"Live Optics collection script for NetBackup on Windows";
"------------------------------------------------------";
$date=Get-Date -Format o;
"Date: " + $date;
"Version: " + $scriptVersion;
""

#
# UTF-8 output to file without BOM
#
function Out-FileUtf8NoBom {

  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$True, Position=0)] [string] $LiteralPath,
    [switch] $Append,
    [switch] $NoClobber,
    [Parameter(ValueFromPipeline=$True)]
    [string[]]$lines
  )

  Begin
  {
	# Make sure that the .NET framework sees the same working dir. as PS
	# and resolve the input path to a full path.
	[System.IO.Directory]::SetCurrentDirectory($PWD) # Caveat: .NET Core doesn't support [Environment]::CurrentDirectory
	$LiteralPath = [IO.Path]::GetFullPath($LiteralPath)

	# If -NoClobber was specified, throw an exception if the target file already
	# exists.
	if ($NoClobber -and (Test-Path $LiteralPath)) {
		Throw [IO.IOException] "The file '$LiteralPath' already exists."
	}

	try {
		
		# Create a StreamWriter object.
		# Note that we take advantage of the fact that the StreamWriter class by default:
		# - uses UTF-8 encoding
		# - without a BOM.
		$sw = New-Object IO.StreamWriter $LiteralPath, $Append

	}
	catch {
		Write-Error "Failed to create output stream."
		Write-Error $_;
		exit;
    }	
  }
  
  Process { 
	try {
		ForEach ($line in $lines) {
			$sw.WriteLine($line)
		}
	}
	catch {
		$sw.Dispose();
		$sw = $null;
		
		Write-Error "Failed to write to stream."
		Write-Error $_;
		exit;
	}
  }
  
  End {
	if ($sw) {
		$sw.Dispose();
	}
  }
}


#
# Create a temporary directory
#
$dt=Get-Date -UFormat %Y%m%d%H%M%S
$tempDir="LiveOpticsNetBackup" + $dt
new-item -type directory -path $tempDir | Out-Null;

if (!(Test-Path $tempDir)) {
    
    Write-Error "Failed to create directory to hold file output: $tempDir";
    exit;
}

"Temporary directory created: " + $tempDir;

#
# Set the path
#
$env:Path="$env:Path;$env:ProgramFiles\veritas\netbackup\bin\admincmd;$env:ProgramFiles\veritas\netbackup\bin;$env:ProgramFiles\veritas\volmgr\bin;$installationPath";

#
# Date information - quick_date.out
#
$quick_date="$tempDir/quick_date.out";
$date=Get-Date -Uformat "%a %m/%d/%Y"
$date | Out-FileUtf8NoBom $quick_date;

#
# Improved date format
#
$quick_psdate="$tempDir/quick_psdate.out";
$date=Get-Date -Format o;
$date | Out-FileUtf8NoBom $quick_psdate;

#
# Script version
#
$quick_scriptVersion="$tempDir/quick_scriptVersion.out";
$scriptVersion | Out-FileUtf8NoBom $quick_scriptVersion;

#
#Windows version
#
$quick_osVersion="$tempDir/quick_windowsversion.out";
[environment]::OSVersion.Version | Out-FileUtf8NoBom $quick_osVersion

#
#Powershell version
#
$quick_psVersion="$tempDir/quick_psversion.out";
$PSVersionTable.PSVersion | Out-FileUtf8NoBom $quick_psVersion

#
# Time information
#
$startTime=[System.DateTime]::Now;
$startTime.ToString("hh tt", [System.Globalization.CultureInfo]::InvariantCulture.DateTimeFormat) | Out-FileUtf8NoBom "$tempDir/quick_time.out";

#
# Timezone information - quick_timezone.out
#
$tz=(& reg query "HKLM\SYSTEM\CurrentControlSet\Control\TimeZoneInformation");
$quick_timezone="$tempDir/quick_timezone.out";
$tz | Out-FileUtf8NoBom $quick_timezone;

#
# Hostname information - quick_hostname.out
#
$hostnameFile="$tempDir/quick_hostname.out";
hostname | Out-FileUtf8NoBom $hostnameFile;

#
# Base date used for drawing the line on backups.
# 120 days is the default.
#
$last=(New-TimeSpan -Days (120));
$lastBackupDate=[System.DateTime]::UtcNow.Subtract($last);
$lastBackupDateString=$lastBackupDate.ToString("MM\/dd\/yyyy");

#
# Last Backup Date that we care about - quick_nbbasedate.out
#
$quick_nbbasedate="$tempDir/quick_nbbasedate.out";
$lastBackupDateString | Out-FileUtf8NoBom $quick_nbbasedate;

#
# Dump environment variables
#
foreach ($e in (gci env:*)) { $e.Name + "=" + $e.Value | Out-FileUtf8NoBom "$tempDir/quick_set.out" -Append; }

#
# quick_bpconfig.out
#
"Running command: bpconfig -L -U > $tempDir/quick_bpconfig.out";

& bpconfig -L -U | Out-FileUtf8NoBom "$tempDir/quick_bpconfig.out";

#
# quick_bpgetconfig.out
#
"Running command: bpgetconfig -X > $tempDir/quick_bpgetconfig.out";

& bpgetconfig -X | Out-FileUtf8NoBom "$tempDir/quick_bpgetconfig.out";

#
# quick_bpminlicense.out
#
"Running command: bpminlicense -list_keys -verbose > $tempDir/quick_bpminlicense.out";

& bpminlicense -list_keys -verbose | Out-FileUtf8NoBom "$tempDir/quick_bpminlicense.out";

#
# quick_bpretlevel.out
#
"Running command: bpretlevel > $tempDir/quick_bpretlevel.out";

& bpretlevel | Out-FileUtf8NoBom "$tempDir/quick_bpretlevel.out";

#
# quick_bpstulist.out
#
"Running command: bpstulist -U -L > $tempDir/quick_bpstulist.out";

& bpstulist -U -L | Out-FileUtf8NoBom "$tempDir/quick_bpstulist.out";

#
# quick_bpstulist_go.out
#
"Running command: bpstulist -U -go -L > $tempDir/quick_bpstulist_go.out";
& bpstulist -U -go -L | Out-FileUtf8NoBom "$tempDir/quick_bpstulist_go.out";

#
# quick_bpclient.out
#
"Running command: bpclient -All -L > $tempDir/quick_bpclient.out";
& bpclient -All -L | Out-FileUtf8NoBom "$tempDir/quick_bpclient.out";

#
# quick_bpplclients.out
#
"Running command: bpplclients > $tempDir/quick_bpplclients.out";
& bpplclients | Out-FileUtf8NoBom "$tempDir/quick_bpplclients.out";

#
# quick_bppllist.out
#
"Running command: bppllist -allpolicies -L -U > $tempDir/quick_bppllist.out";
& bppllist -allpolicies -L -U | Out-FileUtf8NoBom "$tempDir/quick_bppllist.out";

#
# quick_bppllistl.out
#
"Running command: bppllist -allpolicies -l > $tempDir/quick_bppllistl.out";
& bppllist -allpolicies -l > "$tempDir/quick_bppllistl.out";

#
# quick_bpimagelist_err.out
# quick_bpimagelist.out
#
"Running command: bpimagelist -U -force -L -d $lastBackupDateString 2> $errorFile > $tempDir/quick_bpimagelist.out";
$errorFile="$tempDir/quick_bpimagelist_err.out";
& bpimagelist -U -force -L -d $lastBackupDateString 2> $errorFile | Out-FileUtf8NoBom "$tempDir/quick_bpimagelist.out";

#
# Check for errors
#
if ((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) {

    #
    # Command had some errors.
    # Don't use the force command
    #
    move-item -Path $errorFile -Destination "$tempDir/quick_bpimagelist_force_err.out";
    
    "Running command: bpimagelist -U -L -d $lastBackupDateString 2> $errorFile > $tempDir/quick_bpimagelist.out";
    & bpimagelist -U -L -d $lastBackupDateString 2> $errorFile | Out-FileUtf8NoBom "$tempDir/quick_bpimagelist.out";
}

#
# quick_bpimmedial.out
# quick_bpimmedial_err.out
#
$errorFile="$tempDir/quick_bpimmedial_err.out";
"Running command: bpimmedia -U -force -l -d $lastBackupDateString 2> $errorFile > $tempDir/quick_bpimmedial.out";
& bpimmedia -U -force -l -d $lastBackupDateString 2> $errorFile | Out-FileUtf8NoBom "$tempDir/quick_bpimmedial.out";

#
# Check for errors
#
if ((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) {

    #
    # Command had some errors.
    # Don't use the force command
    #
    move-item -Path $errorFile -Destination "$tempDir/quick_bpimmedial_force_err.out";
    
    "Running command: bpimmedia -U -l -d $lastBackupDateString 2> $errorFile > $tempDir/quick_bpimmedial.out";
    & bpimmedia -U -l -d $lastBackupDateString 2> $errorFile | Out-FileUtf8NoBom "$tempDir/quick_bpimmedial.out";
}

#
# quick_bpmedialist.out
#
"Running command: bpmedialist -mlist -U -L > $tempDir/quick_bpmedialist.out";
& bpmedialist -mlist -U -L | Out-FileUtf8NoBom "$tempDir/quick_bpmedialist.out";

#
# quick_bpmedialistsummary.out
#
"Running command: bpmedialist -summary -U -L > $tempDir/quick_bpmedialistsummary.out";
& bpmedialist -summary -U -L | Out-FileUtf8NoBom "$tempDir/quick_bpmedialistsummary.out";

#
# quick_vmquery.out
#
"Running command: vmquery -a > $tempDir/quick_vmquery.out"
& vmquery -a | Out-FileUtf8NoBom "$tempDir/quick_vmquery.out";

#
# quick_tpconfig.out
#
"Running command: tpconfig -dl > $tempDir/quick_tpconfig.out";
& tpconfig -dl | Out-FileUtf8NoBom "$tempDir/quick_tpconfig.out";

#
# quick_tpconfig_virtualmachines.out
#
"Running command: tpconfig -dvirtualmachines > $tempDir/quick_tpconfig_virtualmachines.out";
& tpconfig -dvirtualmachines | Out-FileUtf8NoBom "$tempDir/quick_tpconfig_virtualmachines.out";

#
# quick_tpconfig_diskarrays.out
#
"Running command: tpconfig -ddiskarrays > $tempDir/quick_tpconfig_diskarrays.out";
& tpconfig -ddiskarrays | Out-FileUtf8NoBom "$tempDir/quick_tpconfig_diskarrays.out";

#
# quick_vmglob.out
#
"Running command: vmglob -listall > $tempDir/quick_vmglob.out";
& vmglob -listall | Out-FileUtf8NoBom "$tempDir/quick_vmglob.out";

#
# quick_vmpool.out
#
"Running command: vmpool -listall > $tempDir/quick_vmpool.out";
& vmpool -listall | Out-FileUtf8NoBom "$tempDir/quick_vmpool.out";

#
# quick_vmoprcmd.out
#
"Running command: vmoprcmd -d > $tempDir/quick_vmoprcmd.out";
& vmoprcmd -d | Out-FileUtf8NoBom "$tempDir/quick_vmoprcmd.out";

#
# quick_vmoprcmd_devconfig.out
#
"Running command: vmoprcmd -devconfig -l > $tempDir/quick_vmoprcmd_devconfig.out";
& vmoprcmd -devconfig -l | Out-FileUtf8NoBom "$tempDir/quick_vmoprcmd_devconfig.out";

#
# quick_nbdevquery_listdp.out
#
"Running command: nbdevquery -listdp -U > $tempDir/quick_nbdevquery_listdp.out";
& nbdevquery -listdp -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdp.out";

#
# quick_nbdevquery_liststs.out
#
"Running command: nbdevquery -liststs -U > $tempDir/quick_nbdevquery_liststs.out";
& nbdevquery -liststs -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_liststs.out";

#
# quick_nbdevquery_listdv_pt.out
#
"Running command: nbdevquery -listdv -stype IBM-ProtectTier -U > $tempDir/quick_nbdevquery_listdv_pt.out";
& nbdevquery -listdv -stype IBM-ProtectTier -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_pt.out";

#
# quick_nbdevquery_listdv_pt_d.out
#
"Running command: nbdevquery -listdv -stype IBM-ProtectTier -D > $tempDir/quick_nbdevquery_listdv_pt_d.out";
& nbdevquery -listdv -stype IBM-ProtectTier -D | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_pt_d.out";

#
# $tempDir/quick_nbdevquery_listdv_dd.out
#
"Running command: nbdevquery -listdv -stype DataDomain -U > $tempDir/quick_nbdevquery_listdv_dd.out";
& nbdevquery -listdv -stype DataDomain -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_dd.out";

#
# quick_nbdevquery_listdv_dd_d.out
#
"Running command: nbdevquery -listdv -stype DataDomain -D > $tempDir/quick_nbdevquery_listdv_dd_d.out";
& nbdevquery -listdv -stype DataDomain -D | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_dd_d.out";

#
# quick_nbdevquery_listdv_pd.out
#
"Running command: nbdevquery -listdv -stype PureDisk -U > $tempDir/quick_nbdevquery_listdv_pd.out"
& nbdevquery -listdv -stype PureDisk -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_pd.out";

#
# quick_nbdevquery_listdv_pd_d.out
#
"Running command: nbdevquery -listdv -stype PureDisk -D > $tempDir/quick_nbdevquery_listdv_pd_d.out"
& nbdevquery -listdv -stype PureDisk -D | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_pd_d.out";

#
# quick_nbdevquery_listdv_ad.out
#
"Running command: nbdevquery -listdv -stype AdvancedDisk -U > $tempDir/quick_nbdevquery_listdv_ad.out"
& nbdevquery -listdv -stype AdvancedDisk -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_ad.out";

#
# quick_nbdevquery_listdv_ad_d.out
#
"Running command: nbdevquery -listdv -stype AdvancedDisk -D > $tempDir/quick_nbdevquery_listdv_ad_d.out"
& nbdevquery -listdv -stype AdvancedDisk -D | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listdv_ad_d.out";

#
# quick_nbdevquery_listglobals.out
#
"Running command: nbdevquery -listglobals -U > $tempDir/quick_nbdevquery_listglobals.out"
& nbdevquery -listglobals -U | Out-FileUtf8NoBom "$tempDir/quick_nbdevquery_listglobals.out";

#
# quick_bpdbjobssummary.out
#
"Running command: bpdbjobs -summary > $tempDir/quick_bpdbjobssummary.out"
& bpdbjobs -summary | Out-FileUtf8NoBom "$tempDir/quick_bpdbjobssummary.out";

#
# quick_bpdbjobs.out
#
"Running command: bpdbjobs -report -all_columns > $tempDir/quick_bpdbjobs.out"
& bpdbjobs -report -all_columns | Out-FileUtf8NoBom "$tempDir/quick_bpdbjobs.out";

#
# quick_nbftconfig_listclients.out
#
"Running command: nbftconfig -listclients -verbose > $tempDir/quick_nbftconfig_listclients.out"
& nbftconfig -listclients -verbose | Out-FileUtf8NoBom "$tempDir/quick_nbftconfig_listclients.out";

#
# quick_nbftconfig_listservers.out
#
"Running command: nbftconfig -listservers -verbose > $tempDir/quick_nbftconfig_listservers.out"
& nbftconfig -listservers -verbose | Out-FileUtf8NoBom "$tempDir/quick_nbftconfig_listservers.out";

#
# quick_version.out
#
$versionFilePath = "$env:ProgramFiles\veritas\netbackup\version.txt";

if( Test-Path($versionFilePath) ){
	$versionFileContent = Get-Content $versionFilePath
} elseif( Test-Path($installationPath) ){
	$versionFileContent = Get-Content $installationPath
}

$versionFileContent | Out-FileUtf8NoBom "$tempDir/quick_version.out";


#
# Time information
#
$startTime=[System.DateTime]::Now;
$startTime.ToString("hh tt", [System.Globalization.CultureInfo]::InvariantCulture.DateTimeFormat) > "$tempDir/quick_time2.out";

#
# Completed with the standard scan.
#
#$title = "Optional Client Version and Policy Coverage collection";
#$message = "Do you want to collect data on client versions and policy coverage?";
#$yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Runs the additional collection.";
#$no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Skips that optional step and finishes the collection.";
#$options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
#
#$result = $host.ui.PromptForChoice($title, $message, $options, 0) 
#
#if ($result -eq 0) {
#
#    Get-Content "$tempDir/quick_bpplclients.out" | Select-Object -Skip 2 | ForEach-Object { 
#
#        $coverage=($_ -split " ")[2];
#        
#        "Running command: bpcoverage -c $coverage >> $tempDir/quick_bpcoverage.out";
#        bpcoverage -c $coverage >> "$tempDir/quick_bpcoverage.out";
#    }
#}

#
# Clean up...
#
"File collection is complete."
"Files are located in the following folder:"

(Get-Item $tempDir).FullName;

"Launch the Live Optics collector and add this folder to your NetBackup collection.";
# SIG # Begin signature block
# MIIrBgYJKoZIhvcNAQcCoIIq9zCCKvMCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDOUgCBrMf3vHwG
# j7zFlVgNkccjyroniU2CDBwDD5RKoqCCEqIwggXfMIIEx6ADAgECAhBOQOQ3VO3m
# jAAAAABR05R/MA0GCSqGSIb3DQEBCwUAMIG+MQswCQYDVQQGEwJVUzEWMBQGA1UE
# ChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9s
# ZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIwMDkgRW50cnVzdCwgSW5jLiAtIGZv
# ciBhdXRob3JpemVkIHVzZSBvbmx5MTIwMAYDVQQDEylFbnRydXN0IFJvb3QgQ2Vy
# dGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHMjAeFw0yMTA1MDcxNTQzNDVaFw0zMDEx
# MDcxNjEzNDVaMGkxCzAJBgNVBAYTAlVTMRYwFAYDVQQKDA1FbnRydXN0LCBJbmMu
# MUIwQAYDVQQDDDlFbnRydXN0IENvZGUgU2lnbmluZyBSb290IENlcnRpZmljYXRp
# b24gQXV0aG9yaXR5IC0gQ1NCUjEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCngY/3FEW2YkPy2K7TJV5IT1G/xX2fUBw10dZ+YSqUGW0nRqSmGl33VFFq
# gCLGqGZ1TVSDyV5oG6v2W2Swra0gvVTvRmttAudFrnX2joq5Mi6LuHccUk15iF+l
# OhjJUCyXJy2/2gB9Y3/vMuxGh2Pbmp/DWiE2e/mb1cqgbnIs/OHxnnBNCFYVb5Cr
# +0i6udfBgniFZS5/tcnA4hS3NxFBBuKK4Kj25X62eAUBw2DtTwdBLgoTSeOQm3/d
# vfqsv2RR0VybtPVc51z/O5uloBrXfQmywrf/bhy8yH3m6Sv8crMU6UpVEoScRCV1
# HfYq8E+lID1oJethl3wP5bY9867DwRG8G47M4EcwXkIAhnHjWKwGymUfe5SmS1dn
# DH5erXhnW1XjXuvH2OxMbobL89z4n4eqclgSD32m+PhCOTs8LOQyTUmM4OEAwjig
# nPqEPkHcblauxhpb9GdoBQHNG7+uh7ydU/Yu6LZr5JnexU+HWKjSZR7IH9Vybu5Z
# HFc7CXKd18q3kMbNe0WSkUIDTH0/yvKquMIOhvMQn0YupGaGaFpoGHApOBGAYGuK
# Q6NzbOOzazf/5p1nAZKG3y9I0ftQYNVc/iHTAUJj/u9wtBfAj6ju08FLXxLq/f0u
# DodEYOOp9MIYo+P9zgyEIg3zp3jak/PbOM+5LzPG/wc8Xr5F0wIDAQABo4IBKzCC
# AScwDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB/wQIMAYBAf8CAQEwHQYDVR0lBBYw
# FAYIKwYBBQUHAwMGCCsGAQUFBwMIMDsGA1UdIAQ0MDIwMAYEVR0gADAoMCYGCCsG
# AQUFBwIBFhpodHRwOi8vd3d3LmVudHJ1c3QubmV0L3JwYTAzBggrBgEFBQcBAQQn
# MCUwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDAGA1UdHwQp
# MCcwJaAjoCGGH2h0dHA6Ly9jcmwuZW50cnVzdC5uZXQvZzJjYS5jcmwwHQYDVR0O
# BBYEFIK61j2Xzp/PceiSN6/9s7VpNVfPMB8GA1UdIwQYMBaAFGpyJnrQHu995ztp
# UdRsjZ+QEmarMA0GCSqGSIb3DQEBCwUAA4IBAQAfXkEEtoNwJFMsVXMdZTrA7LR7
# BJheWTgTCaRZlEJeUL9PbG4lIJCTWEAN9Rm0Yu4kXsIBWBUCHRAJb6jU+5J+Nzg+
# LxR9jx1DNmSzZhNfFMylcfdbIUvGl77clfxwfREc0yHd0CQ5KcX+Chqlz3t57jpv
# 3ty/6RHdFoMI0yyNf02oFHkvBWFSOOtg8xRofcuyiq3AlFzkJg4sit1Gw87kVlHF
# VuOFuE2bRXKLB/GK+0m4X9HyloFdaVIk8Qgj0tYjD+uL136LwZNr+vFie1jpUJuX
# bheIDeHGQ5jXgWG2hZ1H7LGerj8gO0Od2KIc4NR8CMKvdgb4YmZ6tvf6yK81MIIG
# RzCCBC+gAwIBAgIQUX2RbT6ZlZkataSfWLbvAzANBgkqhkiG9w0BAQ0FADBPMQsw
# CQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UEAxMfRW50
# cnVzdCBDb2RlIFNpZ25pbmcgQ0EgLSBPVkNTMjAeFw0yMjA1MDQxOTA1MzhaFw0y
# MzA1MjIxOTA1MzhaMIGKMQswCQYDVQQGEwJVUzEOMAwGA1UECBMFVGV4YXMxEzAR
# BgNVBAcTClJvdW5kIFJvY2sxHzAdBgNVBAoTFkRlbGwgVGVjaG5vbG9naWVzIElu
# Yy4xFDASBgNVBAsTC0xpdmUgT3B0aWNzMR8wHQYDVQQDExZEZWxsIFRlY2hub2xv
# Z2llcyBJbmMuMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAoGP+1S0L
# dBtvdJ7FjewqI4InC3j8kKbQByRCgyeuSxiitpoCuzrefSPScMild9gBYoXWMJo3
# FchPRENH23oLgzNFK5dcxOy8hPDF1v7uujOqeLEO/LG9CPWComPja+ANrksBbBRk
# P5r/r6mWkGxzfiFXjOmyz4vEbNZhxnkXcY3IlaaYoGHGDitJqr/pM8oga9hhfbs4
# Wldr8E2hjFTdwAcpx5dPBbQOyLyZCyCnI6IZuSx0NtpvA7xjvGrv6W8GEXMshUIB
# /BpZUMk6goazq3MHP7bZTEWjQOtcsBBFPjtIs0LdxvSPo6+8UcBNevXQ2niI1T6T
# 1fAFSF1iWyC2UqBvjYqzb+zj80ydEGjSDYBPODIvDh9Q7MWIpKPcbv+DhdIy7Prk
# 2IBPD4IwNP8x9jzvbfoKKOsBO3EPZf8TGjwGS8tjvohj+mzpWF8JxvbGcZBiaQXN
# jBupe+8ZJ8mc5W8q6NG3MOtaF5qJ4h4QLvHoDRvrsJGZ4v6YbjqN2DxJAgMBAAGj
# ggFhMIIBXTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBQnj3d5RjDHRTiCYWsmjJb8
# gDUlCTAfBgNVHSMEGDAWgBTvn7p5sHPyJR54nANSnBtThN6N7TBnBggrBgEFBQcB
# AQRbMFkwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDIGCCsG
# AQUFBzAChiZodHRwOi8vYWlhLmVudHJ1c3QubmV0L292Y3MyLWNoYWluLnA3YzAx
# BgNVHR8EKjAoMCagJKAihiBodHRwOi8vY3JsLmVudHJ1c3QubmV0L292Y3MyLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwTAYDVR0gBEUw
# QzA3BgpghkgBhvpsCgEDMCkwJwYIKwYBBQUHAgEWG2h0dHBzOi8vd3d3LmVudHJ1
# c3QubmV0L3JwYTAIBgZngQwBBAEwDQYJKoZIhvcNAQENBQADggIBAAmCZ62zA6/W
# uBMQ+nyAUKb4M2K8jlb2DRYH58lxB8IPS6fcVmgdHxLH78X0ohN74nRwmQl3Kf2K
# bxG3/EV1HNSlniRmVmePog2MqXoXVYrccviXmXbkNKffMf8iCxtcMB606Q/C++C2
# NeR4Av7Xgyr3/aCGzqF+6l9VPifmGkMFSo7kbrFUOUNCG2N7G3/KFleX5rzYpLqh
# p4NkjzOl97kx4ubtnERBRHqL4yzi7OveCICMLDHYD0JAtKiirQDvKX6ROLSe/Tqx
# d/P6URVaNzEFb3bjEPIb41M391E/gvx3T1F67yol6QRjqUSO4TI+hLnqwP6136Uf
# kLVe3CUlyDo7vB8iF8bWEIKIrtSXgSNH+grUy7gLYs390kb91Lvq1VHw+rYpbrJK
# Lk3tQHQ0RAO7TlqqdLIGPzl5Gk+Y5CAJwnsQ4eH9D6BIVQFwZZBtiQKaFzUuz+fc
# HTbxnG7mhrr48lNQnzA09y1o1HLf07a5fbmhLdBq8nltrSFxWqxr1UWZaySRJ/Tw
# TFzIQlOp33fQFESKFuZu3xIta2AK8zMc8N2afvfQo1CS5Qmg/r2jnVlPqMxsVUv1
# PHJDRCgJMDddWkkFIug2cei7aZUZeGMIHzPWu6GSj0RqHWSnSz69leSxWag4RlzN
# Kn+N+dH13DC0o1XONgX4U70Js3ZqfDlOMIIGcDCCBFigAwIBAgIQce9VdK81VMNa
# LGn2b0trzTANBgkqhkiG9w0BAQ0FADBpMQswCQYDVQQGEwJVUzEWMBQGA1UECgwN
# RW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50cnVzdCBDb2RlIFNpZ25pbmcgUm9v
# dCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIENTQlIxMB4XDTIxMDUwNzE5MjA0
# NVoXDTQwMTIyOTIzNTkwMFowTzELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1
# c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZD
# UzIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCemXYXGp5WFwhjLJNN
# g2GEMzQCttlioN7CDrkgTMhXnQ/dVFsNDNYB3S9I4ZEJ4dvIFQSCtnvw2NYwOxlx
# cPuoppf2KV2kDKn0Uz5X2wxObvx2218k6apfQ+OT5w7PyiW8xEwwC1oP5gb05W4M
# mWZYT4NhwnN8XCJvAUXFD/dAT2RL0BcKqQ4eAi+hj0zyZ1DbPuSfwk8/dOsxpNCU
# 0Jm8MJIJasskzaLYdlLQTnWYT2Ra0l6D9FjAXWp1xNg/ZDqLFA3YduHquWvnEXBJ
# EThjE27xxvq9EEU1B+Z2FdB1FqrCQ1f+q/5jc0YioLjz5MdwRgn5qTdBmrNLbB9w
# cqMH9jWSdBFkbvkC1cCSlfGXWX4N7qIl8nFVuJuNv83urt37DOeuMk5QjaHf0XO/
# wc5/ddqrv9CtgjjF54jtom06hhG317DhqIs7DEEXml/kW5jInQCf93PSw+mfBYd5
# IYPWC+3RzAif4PHFyVi6U1/Uh7GLWajSXs1p0D76xDkJr7S17ec8+iKH1nP5F5Vq
# wxz1VXhf1PoLwFs/jHgVDlpMOm7lJpjQJ8wg38CGO3qNZUZ+2WFeqfSuPtT8r0XH
# OrOFBEqLyAlds3sCKFnjhn2AolhAZmLgOFWDq58pQSa6u+nYZPi2uyhzzRVK155z
# 42ZMsVGdgSOLyIZ3srYsNyJwIQIDAQABo4IBLDCCASgwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQU75+6ebBz8iUeeJwDUpwbU4Teje0wHwYDVR0jBBgwFoAU
# grrWPZfOn89x6JI3r/2ztWk1V88wMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAxBgNVHR8EKjAoMCagJKAihiBodHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2NzYnIxLmNybDAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwMwRQYDVR0gBD4wPDAwBgRVHSAAMCgwJgYIKwYBBQUH
# AgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMAgGBmeBDAEEATANBgkqhkiG
# 9w0BAQ0FAAOCAgEAXvOGmTXBee7wEK/XkkPShdBb4Jig4HFRyRTLUJpgDrAEJkmx
# z+m6mwih2kNd1G8jorn4QMdH/k0BC0iQP8jcarQ+UzUovkBKR4VqHndAzIB/YbQ8
# T3mo5qOmoH5EhnG/EhuVgXL3DaXQ3mefxqK48Wr5/P50ZsZk5nk9agNhTksfzCBi
# ywIY7GPtfnE/lroLXmgiZ+wfwNIFFmaxsqTq/MWVo40SpfWN7xsgzZn35zLzWXEf
# 3ZTmeeVSIxBWKvxZOL+/eSWSasf9q2d3cbEEfTWtFME+qPwjF1YIGHzXeiJrkWrM
# NUVtTzudQ50FuJ3z/DQhXAQYMlc4NMHKgyNGpogjIcZ+FICrse+7C6wJP+5TkTGz
# 4lREqrV9MDwsI5zoP6NY6kAIF6MgX3rADNuq/wMWAw10ZCKalF4wNXYT9dPh4+AH
# ytnqRYhGnFTVEOLzMglAtudcFzL+zK/rbc9gPHXz7lxgQFUbtVmvciNoTZx0BAwQ
# ya9QW6cNZg+W5ZqV4CCiGtCw7jhJnipnnpGWbJjbxBBtYHwebkjntn6vMwcSce+9
# lTu+qYPUQn23pzTXX4aRta9WWNpVfRe927zNZEEVjTFRBk+0LrKLPZzzTeNYA1TM
# rIj4UjxOS0YJJRn/FeenmEYufbrq4+N8//m5GZW+drkNebICURpKyJ+IwkMxghe6
# MIIXtgIBATBjME8xCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMu
# MSgwJgYDVQQDEx9FbnRydXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MyAhBRfZFt
# PpmVmRq1pJ9Ytu8DMA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAw
# GQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisG
# AQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEINqxtnISveO2MYqaiAyaMw0d8VUcN801
# T7YEc4SiJllUMA0GCSqGSIb3DQEBAQUABIIBgEMUPAJXWuTfI22nNBjyjJi4glI9
# V9oca3sH2x5EfOJQiyS5QnFsTCKMASzs70Y5WwXyu+rvbZOAggi6o+I6b62iAvBR
# O9+v0rITt5524e3+QDlgv0HQAcILz5DADMhJI1alDJFfN55nh1eGmy7aASdteUwF
# tpnngyerFCa3LJMxhxA6WYowDgnH8LSbSzDZ/ScubXpfWoMCs671Fp/fRlqWBWGr
# PHQBN7IgESABNL8WTtFJfyWE1cxVsMqAXiYJThQjMP3kjUtTc2tUz5gdxHDIxpBV
# R3u/npvXkEIH0cNtd4RA8Ddt0LI2fgGWlftEtoofot9t5ZG+UEyTtOjeV8MJPVeI
# XFnpQijxvJb61AZSgsERsaXs1nb7R3spICc3uHvwCQy9tEHgy0tyBidYpPo8FBdu
# WmtrBHkFwACZxPy5jNAz3k+3Y78q+ex6NqMlIbyIYK9LDom52xEEGxnxJZ1H/+w4
# +br2mXgB8kwqFqhQxza8kGg+kl7PaXKctLd3+6GCFSowghUmBgorBgEEAYI3AwMB
# MYIVFjCCFRIGCSqGSIb3DQEHAqCCFQMwghT/AgEDMQ0wCwYJYIZIAWUDBAIBMIHz
# BgsqhkiG9w0BCRABBKCB4wSB4DCB3QIBAQYKYIZIAYb6bAoDBTAxMA0GCWCGSAFl
# AwQCAQUABCD3e7WP3/kqfAhT2pJAceOpXRnzizQZ7goPBHUamv7rpwIIbTl+g1wr
# BwsYDzIwMjIwNzEyMDkyNjM0WjADAgEBoHmkdzB1MQswCQYDVQQGEwJDQTEQMA4G
# A1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0YXdhMRYwFAYDVQQKEw1FbnRydXN0
# LCBJbmMuMSswKQYDVQQDEyJFbnRydXN0IFRpbWVzdGFtcCBBdXRob3JpdHkgLSBU
# U0ExoIIPVTCCBCowggMSoAMCAQICBDhj3vgwDQYJKoZIhvcNAQEFBQAwgbQxFDAS
# BgNVBAoTC0VudHJ1c3QubmV0MUAwPgYDVQQLFDd3d3cuZW50cnVzdC5uZXQvQ1BT
# XzIwNDggaW5jb3JwLiBieSByZWYuIChsaW1pdHMgbGlhYi4pMSUwIwYDVQQLExwo
# YykgMTk5OSBFbnRydXN0Lm5ldCBMaW1pdGVkMTMwMQYDVQQDEypFbnRydXN0Lm5l
# dCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAoMjA0OCkwHhcNOTkxMjI0MTc1MDUx
# WhcNMjkwNzI0MTQxNTEyWjCBtDEUMBIGA1UEChMLRW50cnVzdC5uZXQxQDA+BgNV
# BAsUN3d3dy5lbnRydXN0Lm5ldC9DUFNfMjA0OCBpbmNvcnAuIGJ5IHJlZi4gKGxp
# bWl0cyBsaWFiLikxJTAjBgNVBAsTHChjKSAxOTk5IEVudHJ1c3QubmV0IExpbWl0
# ZWQxMzAxBgNVBAMTKkVudHJ1c3QubmV0IENlcnRpZmljYXRpb24gQXV0aG9yaXR5
# ICgyMDQ4KTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK1NS6kShrLq
# oyAHFRZkKitL0b8LSk2O7YB2pWe3eEDAc0LIaMDbUyvdXrh2mDWTixqdfBM6Dh9b
# tx7P5SQUHrGBqY19uMxrSwPxAgzcq6VAJAB/dJShnQgps4gL9Yd3nVXN5MN+12pk
# q4UUhpVblzJQbz3IumYM4/y9uEnBdolJGf3AqL2Jo2cvxp+8cRlguC3pLMmQdmZ7
# lOKveNZlU1081pyyzykD+S+kULLUSM4FMlWK/bJkTA7kmAd123/fuQhVYIUwKfl7
# SKRphuM1Px6GXXp6Fb3vAI4VIlQXAJAmk7wOSWiRv/hH052VQsEOTd9vJs/DGCFi
# ZkNw1tXAB+ECAwEAAaNCMEAwDgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMB
# Af8wHQYDVR0OBBYEFFXkgdERgL7YibkIozH5oSQJFrlwMA0GCSqGSIb3DQEBBQUA
# A4IBAQA7m49WmzDnU5l8enmnTZfXGZWQ+wYfyjN8RmOPlmYk+kAbISfK5nJz8k/+
# MZn9yAxMaFPGgIITmPq2rdpdPfHObvYVEZSCDO4/la8Rqw/XL94fA49XLB7Ju5oa
# RJXrGE+mH819VxAvmwQJWoS1btgdOuHWntFseV55HBTF49BMkztlPO3fPb6m5ZUa
# w7UZw71eW7v/I+9oGcsSkydcAy1vMNAethqs3lr30aqoJ6b+eYHEeZkzV7oSsKng
# QmyTylbe/m2ECwiLfo3q15ghxvPnPHkvXpzRTBWN4ewiN8yaQwuX3ICQjbNnm29I
# CBVWz7/xK3xemnbpWZDFfIM1EWVRMIIFEzCCA/ugAwIBAgIMWNoT/wAAAABRzg33
# MA0GCSqGSIb3DQEBCwUAMIG0MRQwEgYDVQQKEwtFbnRydXN0Lm5ldDFAMD4GA1UE
# CxQ3d3d3LmVudHJ1c3QubmV0L0NQU18yMDQ4IGluY29ycC4gYnkgcmVmLiAobGlt
# aXRzIGxpYWIuKTElMCMGA1UECxMcKGMpIDE5OTkgRW50cnVzdC5uZXQgTGltaXRl
# ZDEzMDEGA1UEAxMqRW50cnVzdC5uZXQgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkg
# KDIwNDgpMB4XDTE1MDcyMjE5MDI1NFoXDTI5MDYyMjE5MzI1NFowgbIxCzAJBgNV
# BAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMuMSgwJgYDVQQLEx9TZWUgd3d3
# LmVudHJ1c3QubmV0L2xlZ2FsLXRlcm1zMTkwNwYDVQQLEzAoYykgMjAxNSBFbnRy
# dXN0LCBJbmMuIC0gZm9yIGF1dGhvcml6ZWQgdXNlIG9ubHkxJjAkBgNVBAMTHUVu
# dHJ1c3QgVGltZXN0YW1waW5nIENBIC0gVFMxMIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEA2SPmFKTofEuFcVj7+IHmcotdRsOIAB840Irh1m5WMOWv2mRQ
# fcITOfu9ZrTahPuD0Cgfy3boYFBpm/POTxPiwT7B3xLLMqP4XkQiDsw66Y1JuWB0
# yN5UPUFeQ18oRqmmt8oQKyK8W01bjBdlEob9LHfVxaCMysKD4EdXfOdwrmJFJzEY
# CtTApBhVUvdgxgRLs91oMm4QHzQRuBJ4ZPHuqeD347EijzRaZcuK9OFFUHTfk5em
# NObQTDufN0lSp1NOny5nXO2W/KW/dFGI46qOvdmxL19QMBb0UWAia5nL/+FUO7n7
# RDilCDkjm2lH+jzE0Oeq30ay7PKKGawpsjiVdQIDAQABo4IBIzCCAR8wEgYDVR0T
# AQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAQYwOwYDVR0gBDQwMjAwBgRVHSAA
# MCgwJgYIKwYBBQUHAgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMDMGCCsG
# AQUFBwEBBCcwJTAjBggrBgEFBQcwAYYXaHR0cDovL29jc3AuZW50cnVzdC5uZXQw
# MgYDVR0fBCswKTAnoCWgI4YhaHR0cDovL2NybC5lbnRydXN0Lm5ldC8yMDQ4Y2Eu
# Y3JsMBMGA1UdJQQMMAoGCCsGAQUFBwMIMB0GA1UdDgQWBBTDwnHSe9doBa47OZs0
# JQxiA8dXaDAfBgNVHSMEGDAWgBRV5IHREYC+2Im5CKMx+aEkCRa5cDANBgkqhkiG
# 9w0BAQsFAAOCAQEAHSTnmnRbqnD8sQ4xRdcsAH9mOiugmjSqrGNtifmf3w13/SQj
# /E+ct2+P8/QftsH91hzEjIhmwWONuld307gaHshRrcxgNhqHaijqEWXezDwsjHS3
# 6FBD08wo6BVsESqfFJUpyQVXtWc26Dypg+9BwSEW0373LRFHZnZgghJpjHZVcw/f
# L0td6Wwj+Af2tX3WaUWcWH1hLvx4S0NOiZFGRCygU6hFofYWWLuRE/JLxd8LwOeu
# KXq9RbPncDDnNI7revbTtdHeaxOZRrOL0k2TdbXxb7/cACjCJb+856NlNOw/DR2X
# jPqqiCKkGDXbBY524xDIKY9j0K6sGNnaxJ9REjCCBgwwggT0oAMCAQICEQCNzhXz
# p5TFhwAAAABVkjP0MA0GCSqGSIb3DQEBCwUAMIGyMQswCQYDVQQGEwJVUzEWMBQG
# A1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5l
# dC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIwMTUgRW50cnVzdCwgSW5jLiAt
# IGZvciBhdXRob3JpemVkIHVzZSBvbmx5MSYwJAYDVQQDEx1FbnRydXN0IFRpbWVz
# dGFtcGluZyBDQSAtIFRTMTAeFw0yMDA3MjIxNTMzMjlaFw0zMDEyMjkxNjI5MjNa
# MHUxCzAJBgNVBAYTAkNBMRAwDgYDVQQIEwdPbnRhcmlvMQ8wDQYDVQQHEwZPdHRh
# d2ExFjAUBgNVBAoTDUVudHJ1c3QsIEluYy4xKzApBgNVBAMTIkVudHJ1c3QgVGlt
# ZXN0YW1wIEF1dGhvcml0eSAtIFRTQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDKPuwkYuH3/t/RNqk3ZtZ5FxSUQgCkhpe4J4zrT6n3067iqzAECChf
# m1Omh4ot3QJSX7W45bZQ8JyrEsHuGlZ4im5EP6mKj9fbU9nGR8gM3EZXAGcGFxqF
# t0Cqr3YH55BflJLVrtbXzXmhxTUrRIRfSRzVc7iBjXKUAmqpz1aSqjaUw1DJVpeI
# XOF/X/373xSOPaskDfZ7j2r6bh76lb19kPjkQhS/VV4EVJMxQ/fD58IFEWisQGnH
# IzfsWkwpyd81s35JTsZ6287CJZSeNz+I7CRNOY9/7xVrVExx8Q0hfFp10IdTiaBb
# 4B37nAfAqKG0ItBipMcXfzdOzi06WOPl8CaGTUIHn76j4hmia3KlRr/LZFslyEX0
# 3ug8tv2c86Dvg0F8NnCQw1JisMd/PXvlloelVv8O6kkF37TdE29F05vII3kqMJmd
# mdzMzaUugVNSIvLQPaI3UpGRRnDWxUsF/0703GQGl/58kIYnr580VUiJqyLAdQeM
# IdkE0xyn6m2kyVIr4sQCiTBe55sx5jllrXGt72db3KMk7Q3m4ql6OhhV3vBGLjRN
# Gk2YgA1O0WyFdbgDwgDVIkom0Y7d7bXUJ9Y6fGdphtdUP5fPZL6Rq262nRkQebWX
# DvTRhcnkrsfAtKoHxB/BOlefzQ6meuUVhrKq9KKTLM+M91H63YzQSQIDAQABo4IB
# VzCCAVMwDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMEEG
# A1UdIAQ6MDgwNgYKYIZIAYb6bAoDBTAoMCYGCCsGAQUFBwIBFhpodHRwOi8vd3d3
# LmVudHJ1c3QubmV0L3JwYTAJBgNVHRMEAjAAMGgGCCsGAQUFBwEBBFwwWjAjBggr
# BgEFBQcwAYYXaHR0cDovL29jc3AuZW50cnVzdC5uZXQwMwYIKwYBBQUHMAKGJ2h0
# dHA6Ly9haWEuZW50cnVzdC5uZXQvdHMxLWNoYWluMjU2LmNlcjAxBgNVHR8EKjAo
# MCagJKAihiBodHRwOi8vY3JsLmVudHJ1c3QubmV0L3RzMWNhLmNybDAfBgNVHSME
# GDAWgBTDwnHSe9doBa47OZs0JQxiA8dXaDAdBgNVHQ4EFgQULVaA7473SkMcQ6G1
# 3tnXqKprJigwDQYJKoZIhvcNAQELBQADggEBAFhLztj+gddR2MdcjZLSTpUehYZD
# 7eAa5pohQjNd45G++FB8dowlqUHUhJno6KK2mZdooiC9MqiqKXwKdhqfyFWOq9N7
# 1ON+WX6ScDkP7fYv80//dFzz5zA0QKMRo2typDIRBXz9kYtHqFc2Usf6tUWE0bI+
# QuUWXt0D06n9PXBnetoT4ISCZzhgVsOtsIjhCjd+YoEGuyME71igI6jRCWMwzdkZ
# OPTrWndYvl+/65Qt/y8EMGQQjz5ZVi46Nk8OPJYPj8nqfn9JMh+jX27aIp/X2Rc5
# Wd5IF3oCS1hx/7cMLaHwZ6MR3PfJvNkey2wMFSd4SBZrLPGtl7h1bLuVw44xggSa
# MIIElgIBATCByDCBsjELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1c3QsIElu
# Yy4xKDAmBgNVBAsTH1NlZSB3d3cuZW50cnVzdC5uZXQvbGVnYWwtdGVybXMxOTA3
# BgNVBAsTMChjKSAyMDE1IEVudHJ1c3QsIEluYy4gLSBmb3IgYXV0aG9yaXplZCB1
# c2Ugb25seTEmMCQGA1UEAxMdRW50cnVzdCBUaW1lc3RhbXBpbmcgQ0EgLSBUUzEC
# EQCNzhXzp5TFhwAAAABVkjP0MAsGCWCGSAFlAwQCAaCCAaYwGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yMjA3MTIwOTI2MzRaMCkG
# CSqGSIb3DQEJNDEcMBowCwYJYIZIAWUDBAIBoQsGCSqGSIb3DQEBCzAvBgkqhkiG
# 9w0BCQQxIgQghLz+WjieQAFlK8VurrpYua1L32rty7Dzhmp51610N2AwggEMBgsq
# hkiG9w0BCRACLzGB/DCB+TCB9jCB8wQglQom/cfAIBjp95GpXDjybu89pDJnyrDN
# FaVVr2MQcskwgc4wgbikgbUwgbIxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRy
# dXN0LCBJbmMuMSgwJgYDVQQLEx9TZWUgd3d3LmVudHJ1c3QubmV0L2xlZ2FsLXRl
# cm1zMTkwNwYDVQQLEzAoYykgMjAxNSBFbnRydXN0LCBJbmMuIC0gZm9yIGF1dGhv
# cml6ZWQgdXNlIG9ubHkxJjAkBgNVBAMTHUVudHJ1c3QgVGltZXN0YW1waW5nIENB
# IC0gVFMxAhEAjc4V86eUxYcAAAAAVZIz9DALBgkqhkiG9w0BAQsEggIAA9BB/2DD
# +ZQaPoGKo/adz2tO3ji8/YYYuEKVzp9gnR9/Q5eR3GmzCs1+BX/awyM/B5XdmQPB
# gw3yGDf0rtXUH6RbFgU7H6PqGDvIEUqyeuQQt5iLQEuwz8DImZ6E1ec11NhkBCBk
# xoFu76t/1TwNf6F1WOnDW0O3wIMq3Zjs8bzmyPwVUDRfQ3XeEPf+pdcPPmLCHNfE
# UvoFhfXW+FN44Z363tsSWtyt3D6rpgApGfBsgiVbNWKfoYig2J9tjstN0GRUX5hx
# ZD3NUQwiCzFu5YAPH95TT9WrUUH04UhH7rWDwhwTvaCNrM+aNuoA14KR3kfrt2Ns
# oZa7JrbpZJG+6dR1Q+wXOzPCyZVW2K8GqD8PeunHSICzim6qeF8ifrjqSa7O5WWD
# voa+cKBykPaxiRtd+P+T0WDWtnR8vIKrs6zzk286/V4f5uDbRquoOzl9c5NODtX9
# I+KNBw3EFIFdadESt2wqkIzf9tb3E6xE42ANjeoCcWLKhtjy2KcevIujlATOYp6A
# tInf2tFfDrWtgYrHeEVv6ZBGeAOkaLHy1/ezBz4+9pQQleijUvscE6XZvOjWTKrv
# do4tOycJnQ1NE3Lu1es44r6KYLCZN+HOLWECbeFKnuDpWiisPg721CSvtMaHwdUV
# emygESF5ZgICDD1Dm27BJWuFagfKKfELulY=
# SIG # End signature block
