<#

.SYNOPSIS
This Powershell script can be run on a server to gather a file collection from a NetWorker instance.
The generated files can be uploaded to LiveOpics through the collector for analysis. 

.DESCRIPTION
This script will run queries against NetWorker and produce .out files for analysis.

.LINK
https://www.liveoptics.com/

#>

#-----------------------------------------------------------------------------
#  Copyright (c) 2017-2019 by Dell Inc. 
# 
#  All rights reserved.  
# 
#-----------------------------------------------------------------------------


#
# Create a temporary directory
#
$dt=Get-Date -UFormat %Y%m%d%H%M%S
$tempDir="LiveOpticsNetWorker" + $dt
new-item -type directory -path $tempDir | Out-Null;

if (!(Test-Path $tempDir)) {
    
    Write-Error "Failed to create directory to hold file output: $tempDir";
    exit;
}

"Temporary directory created: " + $tempDir;


$ErrorActionPreference="SilentlyContinue"
Stop-Transcript | out-null
$ErrorActionPreference = "Continue"
Start-Transcript $tempDir\script-logs.txt -append

$scriptVersion="PowerShell.1.1.0";

""
"------------------------------------------------------";
"Live Optics collection script for NetWorker on Windows";
"------------------------------------------------------";
$date=Get-Date -Format o;
"Date: " + $date;
"Version: " + $scriptVersion;
""

#
# UTF-8 output to file without BOM
#
function Out-FileUtf8NoBom {

  [CmdletBinding()]
  param(
    [Parameter(Mandatory=$True, Position=0)] [string] $LiteralPath,
    [switch] $Append,
    [switch] $NoClobber,
    [Parameter(ValueFromPipeline=$True)]
    [string[]]$lines
  )

  Begin
  {
	# Make sure that the .NET framework sees the same working dir. as PS
	# and resolve the input path to a full path.
	[System.IO.Directory]::SetCurrentDirectory($PWD) # Caveat: .NET Core doesn't support [Environment]::CurrentDirectory
	$LiteralPath = [IO.Path]::GetFullPath($LiteralPath)

	# If -NoClobber was specified, throw an exception if the target file already
	# exists.
	if ($NoClobber -and (Test-Path $LiteralPath)) {
		Throw [IO.IOException] "The file '$LiteralPath' already exists."
	}

	try {
		
		# Create a StreamWriter object.
		# Note that we take advantage of the fact that the StreamWriter class by default:
		# - uses UTF-8 encoding
		# - without a BOM.
		$sw = New-Object IO.StreamWriter $LiteralPath, $Append

	}
	catch {
		Write-Error "Failed to create output stream."
		Write-Error $_;
		exit;
    }	
  }
  
  Process { 
	try {
		ForEach ($line in $lines) {
			$sw.WriteLine($line)
		}
	}
	catch {
		$sw.Dispose();
		$sw = $null;
		
		Write-Error "Failed to write to stream."
		Write-Error $_;
		exit;
	}
  }
  
  End {
	if ($sw) {
		$sw.Dispose();
	}
  }
}


#
# Set the path
#
$env:Path="$env:Path;$env:ProgramFiles/Legato/nsr/bin";

#
# Date information - quick_date.out
#
$quick_date="$tempDir/nwquick_date.out";
$date=Get-Date -Uformat "%a %m/%d/%Y"
$date | Out-FileUtf8NoBom $quick_date;

#
# Improved date format
#
$quick_psdate="$tempDir/nwquick_psdate.out";
$date=Get-Date -Format o;
$date | Out-FileUtf8NoBom $quick_psdate;

#
# Script version
#
$quick_scriptVersion="$tempDir/nwquick_scriptVersion.out";
$scriptVersion | Out-FileUtf8NoBom $quick_scriptVersion;

#
#Windows version
#
$quick_osVersion="$tempDir/nwquick_windowsversion.out";
[environment]::OSVersion.Version | Out-FileUtf8NoBom $quick_osVersion

#
#Powershell version
#
$quick_psVersion="$tempDir/nwquick_psversion.out";
$PSVersionTable.PSVersion | Out-FileUtf8NoBom $quick_psVersion

#
# Time information
#
$startTime=[System.DateTime]::Now;
$startTime.ToString("hh tt", [System.Globalization.CultureInfo]::InvariantCulture.DateTimeFormat) | Out-FileUtf8NoBom "$tempDir/nwquick_time.out";

#
# Timezone information - quick_timezone.out
#
$tz=(& reg query "HKLM\SYSTEM\CurrentControlSet\Control\TimeZoneInformation");
$quick_timezone="$tempDir/nwquick_timezone.out";
$tz | Out-FileUtf8NoBom $quick_timezone;

#
# Hostname information - quick_hostname.out
#
$hostnameFile="$tempDir/nwquick_hostname.out";
hostname | Out-FileUtf8NoBom $hostnameFile;

#
# Base date used for drawing the line on backups.
# 120 days is the default.
#
$last=(New-TimeSpan -Days (120));
$lastBackupDate=[System.DateTime]::UtcNow.Subtract($last);
$lastBackupDateString="-t " + $lastBackupDate.ToString("MM\/dd\/yyyy");
$lastBackupDateString | Out-FileUtf8NoBom "$tempDir/nwquick_timeconstraint.out";

#
# Dump environment variables
#
foreach ($e in (gci env:*)) { $e.Name + "=" + $e.Value | Out-FileUtf8NoBom "$tempDir/nwquick_set.out" -Append; }

#
# NetWorker Commands
#
$nsradmin="nsradmin";
$nsrlic="nsrlic";
$mminfo="mminfo";


#
# Get NetWorker version
#
$arrayVersionCommandFile="$tempDir/ArrayVersionCommandFile.txt";

"show version" | Out-FileUtf8NoBom $arrayVersionCommandFile;
"p NSR" | Out-FileUtf8NoBom $arrayVersionCommandFile -Append;

"Running command for NetWorker version: nsradmin -i";

& $nsradmin -i "$arrayVersionCommandFile" 2> "$tempDir/nwquick_nsradminversion_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_nsradminversion.out";

#
# Parse major and minor versions
#
$NetworkerMajorVersion = 0;
$NetworkerMinorVersion = 0;

try
{
	if ( (test-path "$tempDir/nwquick_nsradminversion.out") -and ( (get-childitem "$tempDir/nwquick_nsradminversion.out").Length -gt 0) )
    {
		$VersionPattern = "NetWorker\s+(\d+)\.(\d+)";
	
		# Convert input file to a string
		if ([string](Get-Content -Path "$tempDir/nwquick_nsradminversion.out") -match $VersionPattern)	
        {
			if ($Matches.Count -eq 3)
            {
				$NetworkerMajorVersion = $Matches[1];
				$NetworkerMinorVersion = $Matches[2];				
				
				Write-Output "NetworkerMajorVersion = $NetworkerMajorVersion";
				Write-Output "NetworkerMinorVersion = $NetworkerMinorVersion";
			}
			else
			{
				Write-Error "ERROR.  Unable to parse NetWorker version.";
				exit;
			}
		}
		else
		{
			Write-Error "ERROR.  Unable to find NetWorker version.";
			exit;
		}
	}
	else
	{
		Write-Error "ERROR.  NetWorker version file does not exist or is empty.";
		exit;
	}
}
catch
{
	Write-Error "ERROR.  Failed to find Networker version file.";
	exit;
}


#
# Get configuration information (including time zone)
#
$commandFile="$tempDir/CommandFile.txt";

"show" | Out-FileUtf8NoBom $commandFile;
"option hidden" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append; 

"Running command: nsradmin -i";

& $nsradmin -i "$commandFile" 2> "$tempDir/nwquick_nsradmin_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_nsradmin.out";



"Running command:  nsradmin -i";
"show" | Out-FileUtf8NoBom $commandFile;
"option hidden" | Out-FileUtf8NoBom $commandFile -Append;
". NSR" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append;
". NSR client" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append
". NSR pool" | Out-FileUtf8NoBom $commandFile -Append;
"p" | Out-FileUtf8NoBom $commandFile -Append;
& "$nsradmin" -i "$commandFile" | Out-FileUtf8NoBom "$tempDir/nwquick_nsradmin_single.out" 2> "$tempDir/nwquick_nsradmin_single_err.out";


#
# Check for errors
#
$errorFile="$tempDir/nwquick_nsradmin_err.out";

if ((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) {
    Write-Error "ERROR.  Unable to run nsradmin.";
    exit;
}

"NetWorker Major version: " + $NetworkerMajorVersion;
"NetWorker Minor version: " + $NetworkerMinorVersion;

#
# Determine if -I option (ISO 8601) can be used.  Versions 9.2 and 18.x (and above) support it.
#
$isoTimestampFlag="";
if ( ( [int]$NetworkerMajorVersion -eq 9 -and [int]$NetworkerMinorVersion -ge 2 ) -or ( [int]$NetworkerMajorVersion -ge 18 ) )
{
	$isoTimestampFlag="-I";
}

echo "isoTimestampFlag = $isoTimestampFlag";


"Running command: nsrlic -v";
& $nsrlic -v 2> $tempDir/nwquick_nsrlic_2_err.out | Out-FileUtf8NoBom $tempdir/nwquick_nsrlic.out;

$errorFile="$tempDir/nwquick_mminfojobs_err.out";

$errorString="unknown report constraint:";
$mminfojobsout="$tempDir/nwquick_mminfojobs.out";

"Running command: mminfo";
& $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r 'ssid,state,volume,client,pool,capacity,location,name,sscreate(50),sscomp(50),savetime(50),level,totalsize,nfiles,ssretent(50),copies,ssflags,group,ssbrowse(50),cloneid,clonetime(50),clflags,fragsize,sumsize,ssaccess(50),clretent(50),vmname,backup_size,attrs' 2> $errorFile | Out-FileUtf8NoBom $mminfojobsout;

#
# Check for errors
#
if (((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) -or ($(get-content -first 1 $mminfojobsout) -like "*unknown report constraint*")) {

	"Trying mminfo command for NetWorker version 7.5 or older...";
	remove-item $mminfojobsout;
    remove-item $errorFile;

    & $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r 'ssid,state,volume,client,pool,capacity,location,name,sscreate(50),sscomp(50),savetime(50),level,totalsize,nfiles,ssretent(50),copies,ssflags,group,ssbrowse(50),cloneid,clonetime(50),clflags,fragsize,sumsize,ssaccess(50),clretent(50),attrs' 2> $errorFile | Out-FileUtf8NoBom $mminfojobsout;
    
    if (((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) -or ($(get-content -first 1 $mminfojobsout) -like "*unknown report constraint*")) {
    
		"Trying mminfo command for oldest supported NetWorker version ...";
	
        remove-item $errorFile;
		remove-item $mminfojobsout;
        
        & $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r 'ssid,state,volume,client,pool,capacity,location,name,sscreate(50),sscomp(50),savetime(50),level,totalsize,nfiles,ssretent(50),copies,ssflags,group,ssbrowse(50),cloneid,clonetime(50),clflags,fragsize,sumsize,ssaccess(50),attrs' 2> $errorFile | Out-FileUtf8NoBom $mminfojobsout;
        
        if (((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) -or ($(get-content -first 1 $mminfojobsout) -like "*unknown report constraint*")) {

            Write-Error "ERROR.  Failed to get job info.";
            cat $errorFile;
			cat $mminfojobsout;
            exit;
        }
    }
}
 
"Running command: mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r ssid,ssid(53)";
& $mminfo $isoTimestampFlag -av -xm $lastBackupDateString -r "ssid,ssid(53)" 2> "$tempDir/nwquick_mminfojobs_long_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_mminfojobs_long.out"; 

"Running command: mminfo $isoTimestampFlag -av -xm Getting media info...";
& $mminfo $isoTimestampFlag -av -xm -r 'state,volume,written,pool,%used,read,capacity,avail,volflags,type,family,barcode,volid,location,volaccess,volretent(50),olabel,labeled,recycled,volattrs' 2> "$tempDir/nwquick_mminfomedia_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_mminfomedia.out";

#
# Check for errors
#
$errorFile="$tempDir/nwquick_mminfomedia_err.out";

if ((test-path $errorFile) -and ((get-childitem $errorFile).Length -gt 0)) {
    
    Write-Error "ERROR.  Failed run the mminfo for the media information.";
    exit;
}

"Running command: mminfo $isoTimestampFlag -X -a -xm";
& $mminfo $isoTimestampFlag -X -a -xm 2> "$tempDir/nwquick_mminfosummary_err.out" | Out-FileUtf8NoBom "$tempDir/nwquick_mminfosummary.out";


#
# Time information
#
$startTime=[System.DateTime]::Now;
$startTime.ToString("hh tt", [System.Globalization.CultureInfo]::InvariantCulture.DateTimeFormat) | Out-FileUtf8NoBom "$tempDir/nwquick_time2.out";

#
# Clean up...
#
"File collection is complete."
"Files are located in the following folder:"

(Get-Item $tempDir).FullName;

"Launch the Live Optics collector and add this folder to your NetWorker collection.";

Stop-Transcript
# SIG # Begin signature block
# MIIrBwYJKoZIhvcNAQcCoIIq+DCCKvQCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBX1G5yp8UtxVX7
# 00XQEFipkrpT3B9XDGX6x/z+kOX/0aCCEqIwggXfMIIEx6ADAgECAhBOQOQ3VO3m
# jAAAAABR05R/MA0GCSqGSIb3DQEBCwUAMIG+MQswCQYDVQQGEwJVUzEWMBQGA1UE
# ChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9s
# ZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIwMDkgRW50cnVzdCwgSW5jLiAtIGZv
# ciBhdXRob3JpemVkIHVzZSBvbmx5MTIwMAYDVQQDEylFbnRydXN0IFJvb3QgQ2Vy
# dGlmaWNhdGlvbiBBdXRob3JpdHkgLSBHMjAeFw0yMTA1MDcxNTQzNDVaFw0zMDEx
# MDcxNjEzNDVaMGkxCzAJBgNVBAYTAlVTMRYwFAYDVQQKDA1FbnRydXN0LCBJbmMu
# MUIwQAYDVQQDDDlFbnRydXN0IENvZGUgU2lnbmluZyBSb290IENlcnRpZmljYXRp
# b24gQXV0aG9yaXR5IC0gQ1NCUjEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIK
# AoICAQCngY/3FEW2YkPy2K7TJV5IT1G/xX2fUBw10dZ+YSqUGW0nRqSmGl33VFFq
# gCLGqGZ1TVSDyV5oG6v2W2Swra0gvVTvRmttAudFrnX2joq5Mi6LuHccUk15iF+l
# OhjJUCyXJy2/2gB9Y3/vMuxGh2Pbmp/DWiE2e/mb1cqgbnIs/OHxnnBNCFYVb5Cr
# +0i6udfBgniFZS5/tcnA4hS3NxFBBuKK4Kj25X62eAUBw2DtTwdBLgoTSeOQm3/d
# vfqsv2RR0VybtPVc51z/O5uloBrXfQmywrf/bhy8yH3m6Sv8crMU6UpVEoScRCV1
# HfYq8E+lID1oJethl3wP5bY9867DwRG8G47M4EcwXkIAhnHjWKwGymUfe5SmS1dn
# DH5erXhnW1XjXuvH2OxMbobL89z4n4eqclgSD32m+PhCOTs8LOQyTUmM4OEAwjig
# nPqEPkHcblauxhpb9GdoBQHNG7+uh7ydU/Yu6LZr5JnexU+HWKjSZR7IH9Vybu5Z
# HFc7CXKd18q3kMbNe0WSkUIDTH0/yvKquMIOhvMQn0YupGaGaFpoGHApOBGAYGuK
# Q6NzbOOzazf/5p1nAZKG3y9I0ftQYNVc/iHTAUJj/u9wtBfAj6ju08FLXxLq/f0u
# DodEYOOp9MIYo+P9zgyEIg3zp3jak/PbOM+5LzPG/wc8Xr5F0wIDAQABo4IBKzCC
# AScwDgYDVR0PAQH/BAQDAgGGMBIGA1UdEwEB/wQIMAYBAf8CAQEwHQYDVR0lBBYw
# FAYIKwYBBQUHAwMGCCsGAQUFBwMIMDsGA1UdIAQ0MDIwMAYEVR0gADAoMCYGCCsG
# AQUFBwIBFhpodHRwOi8vd3d3LmVudHJ1c3QubmV0L3JwYTAzBggrBgEFBQcBAQQn
# MCUwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDAGA1UdHwQp
# MCcwJaAjoCGGH2h0dHA6Ly9jcmwuZW50cnVzdC5uZXQvZzJjYS5jcmwwHQYDVR0O
# BBYEFIK61j2Xzp/PceiSN6/9s7VpNVfPMB8GA1UdIwQYMBaAFGpyJnrQHu995ztp
# UdRsjZ+QEmarMA0GCSqGSIb3DQEBCwUAA4IBAQAfXkEEtoNwJFMsVXMdZTrA7LR7
# BJheWTgTCaRZlEJeUL9PbG4lIJCTWEAN9Rm0Yu4kXsIBWBUCHRAJb6jU+5J+Nzg+
# LxR9jx1DNmSzZhNfFMylcfdbIUvGl77clfxwfREc0yHd0CQ5KcX+Chqlz3t57jpv
# 3ty/6RHdFoMI0yyNf02oFHkvBWFSOOtg8xRofcuyiq3AlFzkJg4sit1Gw87kVlHF
# VuOFuE2bRXKLB/GK+0m4X9HyloFdaVIk8Qgj0tYjD+uL136LwZNr+vFie1jpUJuX
# bheIDeHGQ5jXgWG2hZ1H7LGerj8gO0Od2KIc4NR8CMKvdgb4YmZ6tvf6yK81MIIG
# RzCCBC+gAwIBAgIQUX2RbT6ZlZkataSfWLbvAzANBgkqhkiG9w0BAQ0FADBPMQsw
# CQYDVQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UEAxMfRW50
# cnVzdCBDb2RlIFNpZ25pbmcgQ0EgLSBPVkNTMjAeFw0yMjA1MDQxOTA1MzhaFw0y
# MzA1MjIxOTA1MzhaMIGKMQswCQYDVQQGEwJVUzEOMAwGA1UECBMFVGV4YXMxEzAR
# BgNVBAcTClJvdW5kIFJvY2sxHzAdBgNVBAoTFkRlbGwgVGVjaG5vbG9naWVzIElu
# Yy4xFDASBgNVBAsTC0xpdmUgT3B0aWNzMR8wHQYDVQQDExZEZWxsIFRlY2hub2xv
# Z2llcyBJbmMuMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAoGP+1S0L
# dBtvdJ7FjewqI4InC3j8kKbQByRCgyeuSxiitpoCuzrefSPScMild9gBYoXWMJo3
# FchPRENH23oLgzNFK5dcxOy8hPDF1v7uujOqeLEO/LG9CPWComPja+ANrksBbBRk
# P5r/r6mWkGxzfiFXjOmyz4vEbNZhxnkXcY3IlaaYoGHGDitJqr/pM8oga9hhfbs4
# Wldr8E2hjFTdwAcpx5dPBbQOyLyZCyCnI6IZuSx0NtpvA7xjvGrv6W8GEXMshUIB
# /BpZUMk6goazq3MHP7bZTEWjQOtcsBBFPjtIs0LdxvSPo6+8UcBNevXQ2niI1T6T
# 1fAFSF1iWyC2UqBvjYqzb+zj80ydEGjSDYBPODIvDh9Q7MWIpKPcbv+DhdIy7Prk
# 2IBPD4IwNP8x9jzvbfoKKOsBO3EPZf8TGjwGS8tjvohj+mzpWF8JxvbGcZBiaQXN
# jBupe+8ZJ8mc5W8q6NG3MOtaF5qJ4h4QLvHoDRvrsJGZ4v6YbjqN2DxJAgMBAAGj
# ggFhMIIBXTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBQnj3d5RjDHRTiCYWsmjJb8
# gDUlCTAfBgNVHSMEGDAWgBTvn7p5sHPyJR54nANSnBtThN6N7TBnBggrBgEFBQcB
# AQRbMFkwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDIGCCsG
# AQUFBzAChiZodHRwOi8vYWlhLmVudHJ1c3QubmV0L292Y3MyLWNoYWluLnA3YzAx
# BgNVHR8EKjAoMCagJKAihiBodHRwOi8vY3JsLmVudHJ1c3QubmV0L292Y3MyLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwTAYDVR0gBEUw
# QzA3BgpghkgBhvpsCgEDMCkwJwYIKwYBBQUHAgEWG2h0dHBzOi8vd3d3LmVudHJ1
# c3QubmV0L3JwYTAIBgZngQwBBAEwDQYJKoZIhvcNAQENBQADggIBAAmCZ62zA6/W
# uBMQ+nyAUKb4M2K8jlb2DRYH58lxB8IPS6fcVmgdHxLH78X0ohN74nRwmQl3Kf2K
# bxG3/EV1HNSlniRmVmePog2MqXoXVYrccviXmXbkNKffMf8iCxtcMB606Q/C++C2
# NeR4Av7Xgyr3/aCGzqF+6l9VPifmGkMFSo7kbrFUOUNCG2N7G3/KFleX5rzYpLqh
# p4NkjzOl97kx4ubtnERBRHqL4yzi7OveCICMLDHYD0JAtKiirQDvKX6ROLSe/Tqx
# d/P6URVaNzEFb3bjEPIb41M391E/gvx3T1F67yol6QRjqUSO4TI+hLnqwP6136Uf
# kLVe3CUlyDo7vB8iF8bWEIKIrtSXgSNH+grUy7gLYs390kb91Lvq1VHw+rYpbrJK
# Lk3tQHQ0RAO7TlqqdLIGPzl5Gk+Y5CAJwnsQ4eH9D6BIVQFwZZBtiQKaFzUuz+fc
# HTbxnG7mhrr48lNQnzA09y1o1HLf07a5fbmhLdBq8nltrSFxWqxr1UWZaySRJ/Tw
# TFzIQlOp33fQFESKFuZu3xIta2AK8zMc8N2afvfQo1CS5Qmg/r2jnVlPqMxsVUv1
# PHJDRCgJMDddWkkFIug2cei7aZUZeGMIHzPWu6GSj0RqHWSnSz69leSxWag4RlzN
# Kn+N+dH13DC0o1XONgX4U70Js3ZqfDlOMIIGcDCCBFigAwIBAgIQce9VdK81VMNa
# LGn2b0trzTANBgkqhkiG9w0BAQ0FADBpMQswCQYDVQQGEwJVUzEWMBQGA1UECgwN
# RW50cnVzdCwgSW5jLjFCMEAGA1UEAww5RW50cnVzdCBDb2RlIFNpZ25pbmcgUm9v
# dCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eSAtIENTQlIxMB4XDTIxMDUwNzE5MjA0
# NVoXDTQwMTIyOTIzNTkwMFowTzELMAkGA1UEBhMCVVMxFjAUBgNVBAoTDUVudHJ1
# c3QsIEluYy4xKDAmBgNVBAMTH0VudHJ1c3QgQ29kZSBTaWduaW5nIENBIC0gT1ZD
# UzIwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCemXYXGp5WFwhjLJNN
# g2GEMzQCttlioN7CDrkgTMhXnQ/dVFsNDNYB3S9I4ZEJ4dvIFQSCtnvw2NYwOxlx
# cPuoppf2KV2kDKn0Uz5X2wxObvx2218k6apfQ+OT5w7PyiW8xEwwC1oP5gb05W4M
# mWZYT4NhwnN8XCJvAUXFD/dAT2RL0BcKqQ4eAi+hj0zyZ1DbPuSfwk8/dOsxpNCU
# 0Jm8MJIJasskzaLYdlLQTnWYT2Ra0l6D9FjAXWp1xNg/ZDqLFA3YduHquWvnEXBJ
# EThjE27xxvq9EEU1B+Z2FdB1FqrCQ1f+q/5jc0YioLjz5MdwRgn5qTdBmrNLbB9w
# cqMH9jWSdBFkbvkC1cCSlfGXWX4N7qIl8nFVuJuNv83urt37DOeuMk5QjaHf0XO/
# wc5/ddqrv9CtgjjF54jtom06hhG317DhqIs7DEEXml/kW5jInQCf93PSw+mfBYd5
# IYPWC+3RzAif4PHFyVi6U1/Uh7GLWajSXs1p0D76xDkJr7S17ec8+iKH1nP5F5Vq
# wxz1VXhf1PoLwFs/jHgVDlpMOm7lJpjQJ8wg38CGO3qNZUZ+2WFeqfSuPtT8r0XH
# OrOFBEqLyAlds3sCKFnjhn2AolhAZmLgOFWDq58pQSa6u+nYZPi2uyhzzRVK155z
# 42ZMsVGdgSOLyIZ3srYsNyJwIQIDAQABo4IBLDCCASgwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQU75+6ebBz8iUeeJwDUpwbU4Teje0wHwYDVR0jBBgwFoAU
# grrWPZfOn89x6JI3r/2ztWk1V88wMwYIKwYBBQUHAQEEJzAlMCMGCCsGAQUFBzAB
# hhdodHRwOi8vb2NzcC5lbnRydXN0Lm5ldDAxBgNVHR8EKjAoMCagJKAihiBodHRw
# Oi8vY3JsLmVudHJ1c3QubmV0L2NzYnIxLmNybDAOBgNVHQ8BAf8EBAMCAYYwEwYD
# VR0lBAwwCgYIKwYBBQUHAwMwRQYDVR0gBD4wPDAwBgRVHSAAMCgwJgYIKwYBBQUH
# AgEWGmh0dHA6Ly93d3cuZW50cnVzdC5uZXQvcnBhMAgGBmeBDAEEATANBgkqhkiG
# 9w0BAQ0FAAOCAgEAXvOGmTXBee7wEK/XkkPShdBb4Jig4HFRyRTLUJpgDrAEJkmx
# z+m6mwih2kNd1G8jorn4QMdH/k0BC0iQP8jcarQ+UzUovkBKR4VqHndAzIB/YbQ8
# T3mo5qOmoH5EhnG/EhuVgXL3DaXQ3mefxqK48Wr5/P50ZsZk5nk9agNhTksfzCBi
# ywIY7GPtfnE/lroLXmgiZ+wfwNIFFmaxsqTq/MWVo40SpfWN7xsgzZn35zLzWXEf
# 3ZTmeeVSIxBWKvxZOL+/eSWSasf9q2d3cbEEfTWtFME+qPwjF1YIGHzXeiJrkWrM
# NUVtTzudQ50FuJ3z/DQhXAQYMlc4NMHKgyNGpogjIcZ+FICrse+7C6wJP+5TkTGz
# 4lREqrV9MDwsI5zoP6NY6kAIF6MgX3rADNuq/wMWAw10ZCKalF4wNXYT9dPh4+AH
# ytnqRYhGnFTVEOLzMglAtudcFzL+zK/rbc9gPHXz7lxgQFUbtVmvciNoTZx0BAwQ
# ya9QW6cNZg+W5ZqV4CCiGtCw7jhJnipnnpGWbJjbxBBtYHwebkjntn6vMwcSce+9
# lTu+qYPUQn23pzTXX4aRta9WWNpVfRe927zNZEEVjTFRBk+0LrKLPZzzTeNYA1TM
# rIj4UjxOS0YJJRn/FeenmEYufbrq4+N8//m5GZW+drkNebICURpKyJ+IwkMxghe7
# MIIXtwIBATBjME8xCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMu
# MSgwJgYDVQQDEx9FbnRydXN0IENvZGUgU2lnbmluZyBDQSAtIE9WQ1MyAhBRfZFt
# PpmVmRq1pJ9Ytu8DMA0GCWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAw
# GQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisG
# AQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIAeYB/rSZcwUhbz36aZMvEEBM+vvAHjN
# ToQEyVlJV6baMA0GCSqGSIb3DQEBAQUABIIBgJTR3EC7ysDrQ8rcgHLNtjAyeOuC
# 79MrPKj1PQrLzlF/4bk0E2ZFUeifk3KTYiz+sQSJu5a4P3o+NZWab+1MQXF74a01
# 383R0jXpWSJwqcLXkUggWvJl49P7uuxkjbYUDM190D9qMH8VVZDI+7kLqgwxY/uf
# 8vz9r4Fut94DfE7o5dK1HPOK1QngSjawpAWGh7CrWkskIN5x+XLpcaFjervjztBT
# Mgr6KbUnQ7JTdUsA+rSKIs3qy+w4CnunYrMOqhtPbsKUmoga+sAIbdvcOHPV+ynd
# MoP6lRaEaOyVZAJrKzf81geZCz3iu1iILFXggS8foS04vDRE7BLeYLMt8Cd0TrpL
# x6WxqS7OW6ZJIt4H/ha56cFaOZ/Lo5BF2KDHP6pUuCw96kZnxC78HZzgaCiG4pgk
# qdvvYCioMZN1/igllvgc37tX/UWqRWaDBr8UVb7X5rgsFcHGy7YyXgSC7bVcqNfZ
# OJLSOCS6OhucYhC2vR174cdzY08bcGegzKEbvqGCFSswghUnBgorBgEEAYI3AwMB
# MYIVFzCCFRMGCSqGSIb3DQEHAqCCFQQwghUAAgEDMQ0wCwYJYIZIAWUDBAIBMIH0
# BgsqhkiG9w0BCRABBKCB5ASB4TCB3gIBAQYKYIZIAYb6bAoDBTAxMA0GCWCGSAFl
# AwQCAQUABCA5cNR7Wi6v8gzFJcxXqh+JaB5Q40VtVvYIwVApfRQQIgIJAIpcXHdV
# v3JTGA8yMDIyMDcxMjA5MjYzNFowAwIBAaB5pHcwdTELMAkGA1UEBhMCQ0ExEDAO
# BgNVBAgTB09udGFyaW8xDzANBgNVBAcTBk90dGF3YTEWMBQGA1UEChMNRW50cnVz
# dCwgSW5jLjErMCkGA1UEAxMiRW50cnVzdCBUaW1lc3RhbXAgQXV0aG9yaXR5IC0g
# VFNBMaCCD1UwggQqMIIDEqADAgECAgQ4Y974MA0GCSqGSIb3DQEBBQUAMIG0MRQw
# EgYDVQQKEwtFbnRydXN0Lm5ldDFAMD4GA1UECxQ3d3d3LmVudHJ1c3QubmV0L0NQ
# U18yMDQ4IGluY29ycC4gYnkgcmVmLiAobGltaXRzIGxpYWIuKTElMCMGA1UECxMc
# KGMpIDE5OTkgRW50cnVzdC5uZXQgTGltaXRlZDEzMDEGA1UEAxMqRW50cnVzdC5u
# ZXQgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkgKDIwNDgpMB4XDTk5MTIyNDE3NTA1
# MVoXDTI5MDcyNDE0MTUxMlowgbQxFDASBgNVBAoTC0VudHJ1c3QubmV0MUAwPgYD
# VQQLFDd3d3cuZW50cnVzdC5uZXQvQ1BTXzIwNDggaW5jb3JwLiBieSByZWYuIChs
# aW1pdHMgbGlhYi4pMSUwIwYDVQQLExwoYykgMTk5OSBFbnRydXN0Lm5ldCBMaW1p
# dGVkMTMwMQYDVQQDEypFbnRydXN0Lm5ldCBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0
# eSAoMjA0OCkwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCtTUupEoay
# 6qMgBxUWZCorS9G/C0pNju2AdqVnt3hAwHNCyGjA21Mr3V64dpg1k4sanXwTOg4f
# W7cez+UkFB6xgamNfbjMa0sD8QIM3KulQCQAf3SUoZ0IKbOIC/WHd51VzeTDftdq
# ZKuFFIaVW5cyUG89yLpmDOP8vbhJwXaJSRn9wKi9iaNnL8afvHEZYLgt6SzJkHZm
# e5Tir3jWZVNdPNacss8pA/kvpFCy1EjOBTJViv2yZEwO5JgHddt/37kIVWCFMCn5
# e0ikaYbjNT8ehl16ehW97wCOFSJUFwCQJpO8Dklokb/4R9OdlULBDk3fbybPwxgh
# YmZDcNbVwAfhAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNVHRMBAf8EBTAD
# AQH/MB0GA1UdDgQWBBRV5IHREYC+2Im5CKMx+aEkCRa5cDANBgkqhkiG9w0BAQUF
# AAOCAQEAO5uPVpsw51OZfHp5p02X1xmVkPsGH8ozfEZjj5ZmJPpAGyEnyuZyc/JP
# /jGZ/cgMTGhTxoCCE5j6tq3aXT3xzm72FRGUggzuP5WvEasP1y/eHwOPVyweybua
# GkSV6xhPph/NfVcQL5sECVqEtW7YHTrh1p7RbHleeRwUxePQTJM7ZTzt3z2+puWV
# GsO1GcO9Xlu7/yPvaBnLEpMnXAMtbzDQHrYarN5a99GqqCem/nmBxHmZM1e6ErCp
# 4EJsk8pW3v5thAsIi36N6teYIcbz5zx5L16c0UwVjeHsIjfMmkMLl9yAkI2zZ5tv
# SAgVVs+/8St8Xpp26VmQxXyDNRFlUTCCBRMwggP7oAMCAQICDFjaE/8AAAAAUc4N
# 9zANBgkqhkiG9w0BAQsFADCBtDEUMBIGA1UEChMLRW50cnVzdC5uZXQxQDA+BgNV
# BAsUN3d3dy5lbnRydXN0Lm5ldC9DUFNfMjA0OCBpbmNvcnAuIGJ5IHJlZi4gKGxp
# bWl0cyBsaWFiLikxJTAjBgNVBAsTHChjKSAxOTk5IEVudHJ1c3QubmV0IExpbWl0
# ZWQxMzAxBgNVBAMTKkVudHJ1c3QubmV0IENlcnRpZmljYXRpb24gQXV0aG9yaXR5
# ICgyMDQ4KTAeFw0xNTA3MjIxOTAyNTRaFw0yOTA2MjIxOTMyNTRaMIGyMQswCQYD
# VQQGEwJVUzEWMBQGA1UEChMNRW50cnVzdCwgSW5jLjEoMCYGA1UECxMfU2VlIHd3
# dy5lbnRydXN0Lm5ldC9sZWdhbC10ZXJtczE5MDcGA1UECxMwKGMpIDIwMTUgRW50
# cnVzdCwgSW5jLiAtIGZvciBhdXRob3JpemVkIHVzZSBvbmx5MSYwJAYDVQQDEx1F
# bnRydXN0IFRpbWVzdGFtcGluZyBDQSAtIFRTMTCCASIwDQYJKoZIhvcNAQEBBQAD
# ggEPADCCAQoCggEBANkj5hSk6HxLhXFY+/iB5nKLXUbDiAAfONCK4dZuVjDlr9pk
# UH3CEzn7vWa02oT7g9AoH8t26GBQaZvzzk8T4sE+wd8SyzKj+F5EIg7MOumNSblg
# dMjeVD1BXkNfKEapprfKECsivFtNW4wXZRKG/Sx31cWgjMrCg+BHV3zncK5iRScx
# GArUwKQYVVL3YMYES7PdaDJuEB80EbgSeGTx7qng9+OxIo80WmXLivThRVB035OX
# pjTm0Ew7nzdJUqdTTp8uZ1ztlvylv3RRiOOqjr3ZsS9fUDAW9FFgImuZy//hVDu5
# +0Q4pQg5I5tpR/o8xNDnqt9GsuzyihmsKbI4lXUCAwEAAaOCASMwggEfMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwDgYDVR0PAQH/BAQDAgEGMDsGA1UdIAQ0MDIwMAYEVR0g
# ADAoMCYGCCsGAQUFBwIBFhpodHRwOi8vd3d3LmVudHJ1c3QubmV0L3JwYTAzBggr
# BgEFBQcBAQQnMCUwIwYIKwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0
# MDIGA1UdHwQrMCkwJ6AloCOGIWh0dHA6Ly9jcmwuZW50cnVzdC5uZXQvMjA0OGNh
# LmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAdBgNVHQ4EFgQUw8Jx0nvXaAWuOzmb
# NCUMYgPHV2gwHwYDVR0jBBgwFoAUVeSB0RGAvtiJuQijMfmhJAkWuXAwDQYJKoZI
# hvcNAQELBQADggEBAB0k55p0W6pw/LEOMUXXLAB/ZjoroJo0qqxjbYn5n98Nd/0k
# I/xPnLdvj/P0H7bB/dYcxIyIZsFjjbpXd9O4Gh7IUa3MYDYah2oo6hFl3sw8LIx0
# t+hQQ9PMKOgVbBEqnxSVKckFV7VnNug8qYPvQcEhFtN+9y0RR2Z2YIISaYx2VXMP
# 3y9LXelsI/gH9rV91mlFnFh9YS78eEtDTomRRkQsoFOoRaH2Fli7kRPyS8XfC8Dn
# ril6vUWz53Aw5zSO63r207XR3msTmUazi9JNk3W18W+/3AAowiW/vOejZTTsPw0d
# l4z6qogipBg12wWOduMQyCmPY9CurBjZ2sSfURIwggYMMIIE9KADAgECAhEAjc4V
# 86eUxYcAAAAAVZIz9DANBgkqhkiG9w0BAQsFADCBsjELMAkGA1UEBhMCVVMxFjAU
# BgNVBAoTDUVudHJ1c3QsIEluYy4xKDAmBgNVBAsTH1NlZSB3d3cuZW50cnVzdC5u
# ZXQvbGVnYWwtdGVybXMxOTA3BgNVBAsTMChjKSAyMDE1IEVudHJ1c3QsIEluYy4g
# LSBmb3IgYXV0aG9yaXplZCB1c2Ugb25seTEmMCQGA1UEAxMdRW50cnVzdCBUaW1l
# c3RhbXBpbmcgQ0EgLSBUUzEwHhcNMjAwNzIyMTUzMzI5WhcNMzAxMjI5MTYyOTIz
# WjB1MQswCQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzEPMA0GA1UEBxMGT3R0
# YXdhMRYwFAYDVQQKEw1FbnRydXN0LCBJbmMuMSswKQYDVQQDEyJFbnRydXN0IFRp
# bWVzdGFtcCBBdXRob3JpdHkgLSBUU0ExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEAyj7sJGLh9/7f0TapN2bWeRcUlEIApIaXuCeM60+p99Ou4qswBAgo
# X5tTpoeKLd0CUl+1uOW2UPCcqxLB7hpWeIpuRD+pio/X21PZxkfIDNxGVwBnBhca
# hbdAqq92B+eQX5SS1a7W1815ocU1K0SEX0kc1XO4gY1ylAJqqc9Wkqo2lMNQyVaX
# iFzhf1/9+98Ujj2rJA32e49q+m4e+pW9fZD45EIUv1VeBFSTMUP3w+fCBRForEBp
# xyM37FpMKcnfNbN+SU7GetvOwiWUnjc/iOwkTTmPf+8Va1RMcfENIXxaddCHU4mg
# W+Ad+5wHwKihtCLQYqTHF383Ts4tOljj5fAmhk1CB5++o+IZomtypUa/y2RbJchF
# 9N7oPLb9nPOg74NBfDZwkMNSYrDHfz175ZaHpVb/DupJBd+03RNvRdObyCN5KjCZ
# nZnczM2lLoFTUiLy0D2iN1KRkUZw1sVLBf9O9NxkBpf+fJCGJ6+fNFVIiasiwHUH
# jCHZBNMcp+ptpMlSK+LEAokwXuebMeY5Za1xre9nW9yjJO0N5uKpejoYVd7wRi40
# TRpNmIANTtFshXW4A8IA1SJKJtGO3e211CfWOnxnaYbXVD+Xz2S+katutp0ZEHm1
# lw700YXJ5K7HwLSqB8QfwTpXn80OpnrlFYayqvSikyzPjPdR+t2M0EkCAwEAAaOC
# AVcwggFTMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDBB
# BgNVHSAEOjA4MDYGCmCGSAGG+mwKAwUwKDAmBggrBgEFBQcCARYaaHR0cDovL3d3
# dy5lbnRydXN0Lm5ldC9ycGEwCQYDVR0TBAIwADBoBggrBgEFBQcBAQRcMFowIwYI
# KwYBBQUHMAGGF2h0dHA6Ly9vY3NwLmVudHJ1c3QubmV0MDMGCCsGAQUFBzAChido
# dHRwOi8vYWlhLmVudHJ1c3QubmV0L3RzMS1jaGFpbjI1Ni5jZXIwMQYDVR0fBCow
# KDAmoCSgIoYgaHR0cDovL2NybC5lbnRydXN0Lm5ldC90czFjYS5jcmwwHwYDVR0j
# BBgwFoAUw8Jx0nvXaAWuOzmbNCUMYgPHV2gwHQYDVR0OBBYEFC1WgO+O90pDHEOh
# td7Z16iqayYoMA0GCSqGSIb3DQEBCwUAA4IBAQBYS87Y/oHXUdjHXI2S0k6VHoWG
# Q+3gGuaaIUIzXeORvvhQfHaMJalB1ISZ6OiitpmXaKIgvTKoqil8CnYan8hVjqvT
# e9Tjfll+knA5D+32L/NP/3Rc8+cwNECjEaNrcqQyEQV8/ZGLR6hXNlLH+rVFhNGy
# PkLlFl7dA9Op/T1wZ3raE+CEgmc4YFbDrbCI4Qo3fmKBBrsjBO9YoCOo0QljMM3Z
# GTj061p3WL5fv+uULf8vBDBkEI8+WVYuOjZPDjyWD4/J6n5/STIfo19u2iKf19kX
# OVneSBd6AktYcf+3DC2h8GejEdz3ybzZHstsDBUneEgWayzxrZe4dWy7lcOOMYIE
# mjCCBJYCAQEwgcgwgbIxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1FbnRydXN0LCBJ
# bmMuMSgwJgYDVQQLEx9TZWUgd3d3LmVudHJ1c3QubmV0L2xlZ2FsLXRlcm1zMTkw
# NwYDVQQLEzAoYykgMjAxNSBFbnRydXN0LCBJbmMuIC0gZm9yIGF1dGhvcml6ZWQg
# dXNlIG9ubHkxJjAkBgNVBAMTHUVudHJ1c3QgVGltZXN0YW1waW5nIENBIC0gVFMx
# AhEAjc4V86eUxYcAAAAAVZIz9DALBglghkgBZQMEAgGgggGmMBoGCSqGSIb3DQEJ
# AzENBgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjIwNzEyMDkyNjM0WjAp
# BgkqhkiG9w0BCTQxHDAaMAsGCWCGSAFlAwQCAaELBgkqhkiG9w0BAQswLwYJKoZI
# hvcNAQkEMSIEIB5eJ6pr58edHMfEuk65R3PRS7wo1A0G3GHcO2BJYZYQMIIBDAYL
# KoZIhvcNAQkQAi8xgfwwgfkwgfYwgfMEIJUKJv3HwCAY6feRqVw48m7vPaQyZ8qw
# zRWlVa9jEHLJMIHOMIG4pIG1MIGyMQswCQYDVQQGEwJVUzEWMBQGA1UEChMNRW50
# cnVzdCwgSW5jLjEoMCYGA1UECxMfU2VlIHd3dy5lbnRydXN0Lm5ldC9sZWdhbC10
# ZXJtczE5MDcGA1UECxMwKGMpIDIwMTUgRW50cnVzdCwgSW5jLiAtIGZvciBhdXRo
# b3JpemVkIHVzZSBvbmx5MSYwJAYDVQQDEx1FbnRydXN0IFRpbWVzdGFtcGluZyBD
# QSAtIFRTMQIRAI3OFfOnlMWHAAAAAFWSM/QwCwYJKoZIhvcNAQELBIICADTeMfkE
# s6QUrSeZdozNb5idMA5ohdGKkxE9MTV6Jy2N4iAS36ExLUtW8xs8WDh6cRqPa/OJ
# 6bPIH3Lpq6NGb0aoDC5zFDvVb2YCAHlguSSx9IhWd0IzGq8WLk5D8NpMqjDGuqJX
# 5EnykiFKsLzOesq20nqOszOiqdOVb7NGd8l+Aj3tOvSBMsFsnpZJ/4V86sEhXHG2
# KP0oL0dasJWRD/0VRQJ6orscoED3ggMxzxUVaws1CvucS/VVuag52HHOunePfcA5
# pxR5KDzug4bx5GXGeMbqvDVn/QdTxsnq+wvdS1cOBI174vSMyHzeVyo+b1HVipUd
# aTjZutWXxNux4lMY1eXJMPgYE0MSGKyLH4jZRU+f7AzeBipo9xn4JQA2jtqukeT9
# /L47xjKXrpDbJhyiBRlRrR2XK6I0Ex6UppfnESDztQRW+j1/nOf9rWvy19THYGjy
# ht5JM5qrt61XKFFjzOEcp43xB8MJglgf/C0o3En4nswGb7u+B05PVTqZ6gEHWTv+
# NTT7H+zplPtLGbKeDszODuoNK5dP1XlX3/rtAw3f2ca0n+JYuOPLfS5XBHujYP7u
# DqiXX+5Jn6ZZH5XS6SBnw7+JxKvvKkUal0/DJCOmOSKvX9zSbhPGUjbp/7aMeOaj
# fIN27SBQi1pen24k0zPUGxdDdqn1h4e3AUbh
# SIG # End signature block
